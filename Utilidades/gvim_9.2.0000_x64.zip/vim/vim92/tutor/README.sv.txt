Tutor är en praktisk handledning för nya användare av Vim-redigeraren.

De flesta nya användare kan gå igenom den på mindre än en timme. Resultatet
är att du kan utföra enkla redigeringsuppgifter med Vim-redigeraren.

Tutor är en fil som innehåller handledningslektionerna. Du kan helt enkelt
köra ”vim tutor1” och sedan följa instruktionerna i lektionerna.
Lektionerna uppmanar dig att ändra filen, så GÖR INTE DETTA PÅ DIN
ORIGINALKOPIA.

På UNIX-liknande system kan du också använda programmet ”vimtutor”.
Det skapar först en provkopia av handledaren.

Jag har funderat på att lägga till mer avancerade lektioner, men har inte hittat
tid. Låt mig veta vad du tycker om den och skicka eventuella förbättringar du
gör.

Bob Ware, Colorado School of Mines, Golden, Co 80401, USA
(303) 273-3987
bware@mines.colorado.edu bware@slate.mines.colorado.edu bware@mines.bitnet

Allt ovanstående om kapitel ett i handledningen gäller även kapitel
två i handledningen. Förutom att du måste använda kommandot ”vim tutor2” för att öppna
kapitel två.

Kapitel två i handledningen är skrivet av Paul D. Parker.

Översättning
-----------
Filerna tutor1.xx för kapitel ett och tutor2.xx för kapitel två i handledningen
är översatta filer (där xx är språkkoden).
Kodningen av tutor1.xx och tutor2.xx måste vara utf-8.

Översättning av Daniel Nylander <vim@danielnylander.se>.

[Denna fil har modifierats för Vim av Bram Moolenaar et al.
